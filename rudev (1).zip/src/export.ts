import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import * as XLSX from 'xlsx';
import { format } from 'date-fns';
import { Task, TaskStatus } from './db';

const statusLabels: Record<TaskStatus, string> = {
  [TaskStatus.NOT_STARTED]: 'Не начато',
  [TaskStatus.IN_PROGRESS]: 'Выполняется',
  [TaskStatus.OVERDUE]: 'Просрочено',
  [TaskStatus.COMPLETED]: 'Выполнено',
};

export const exportToPDF = async (tasks: Task[], titleLabel: string) => {
  console.log('Starting PDF Export with html2canvas...');
  try {
    const element = document.createElement('div');
    // Ensure styles are perfect for rendering
    element.style.position = 'fixed';
    element.style.left = '-9999px';
    element.style.top = '0';
    element.style.width = '700px'; // A4 width-ish
    element.style.backgroundColor = 'white';
    element.style.color = 'black';
    element.style.padding = '40px';
    element.style.fontFamily = '"Segoe UI", Arial, sans-serif';
    
    element.innerHTML = `
      <div style="background: white; color: black; padding: 20px;">
        <h1 style="font-size: 24px; font-weight: bold; margin-bottom: 8px; color: #111; border-bottom: 2px solid #eee; padding-bottom: 12px;">
          Отчет по задачам: ${titleLabel}
        </h1>
        <p style="font-size: 12px; color: #666; margin-bottom: 24px;">
          Дата выгрузки: ${format(new Date(), 'dd.MM.yyyy HH:mm')}
        </p>
        
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr style="background-color: #f8f9fa;">
              <th style="border: 1px solid #dee2e6; padding: 12px; text-align: left; font-size: 13px; font-weight: bold; width: 40%;">Задача</th>
              <th style="border: 1px solid #dee2e6; padding: 12px; text-align: left; font-size: 13px; font-weight: bold; width: 20%;">Срок</th>
              <th style="border: 1px solid #dee2e6; padding: 12px; text-align: left; font-size: 13px; font-weight: bold; width: 20%;">Статус</th>
              <th style="border: 1px solid #dee2e6; padding: 12px; text-align: left; font-size: 13px; font-weight: bold; width: 20%;">Категория</th>
            </tr>
          </thead>
          <tbody>
            ${tasks.map(t => `
              <tr>
                <td style="border: 1px solid #dee2e6; padding: 10px; font-size: 12px; vertical-align: top;">
                  <div style="font-weight: bold; margin-bottom: 4px;">${t.title}</div>
                  <div style="color: #666; font-size: 11px;">${t.comment || ''}</div>
                </td>
                <td style="border: 1px solid #dee2e6; padding: 10px; font-size: 12px; vertical-align: top;">
                  ${t.dueDate} ${t.dueTime}
                </td>
                <td style="border: 1px solid #dee2e6; padding: 10px; font-size: 12px; vertical-align: top;">
                  <span style="display: inline-block; padding: 2px 6px; border-radius: 4px; ${
                    t.status === TaskStatus.COMPLETED ? 'background: #d1fae5; color: #065f46;' :
                    t.status === TaskStatus.OVERDUE ? 'background: #fee2e2; color: #991b1b;' :
                    'background: #f3f4f6; color: #374151;'
                  }">
                    ${statusLabels[t.status] || t.status}
                  </span>
                </td>
                <td style="border: 1px solid #dee2e6; padding: 10px; font-size: 12px; vertical-align: top;">
                  ${(t as any).categoryName || t.category || '-'}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        
        <div style="margin-top: 40px; font-size: 11px; color: #999; text-align: center; border-top: 1px solid #eee; padding-top: 20px;">
          Документ сгенерирован автоматически в приложении RuDev Task Manager
        </div>
      </div>
    `;
    
    document.body.appendChild(element);
    
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff'
    });
    
    document.body.removeChild(element);
    
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'p',
      unit: 'mm',
      format: 'a4',
      compress: true
    });
    
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`RuDev_Tasks_${format(new Date(), 'yyyyMMdd_HHmm')}.pdf`);
  } catch (error) {
    console.error('PDF Export Error:', error);
    alert('Произошла ошибка при создании PDF. Пожалуйста, попробуйте еще раз.');
  }
};

export const exportToExcel = (tasks: Task[], titleLabel: string) => {
  try {
    const worksheet = XLSX.utils.json_to_sheet(tasks.map(t => ({
      'Название': t.title,
      'Категория': (t as any).categoryName || t.category || 'Общее',
      'Дата дедлайна': t.dueDate,
      'Время дедлайна': t.dueTime,
      'Статус': statusLabels[t.status],
      'Комментарий': t.comment,
      'Создано': t.createdAt ? format(new Date(t.createdAt), 'dd.MM.yyyy HH:mm') : '-'
    })));

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Задачи');
    
    XLSX.writeFile(workbook, `tasks_report_${format(new Date(), 'yyyyMMdd_HHmm')}.xlsx`);
  } catch (error) {
    console.error('Error generating Excel:', error);
    alert('Ошибка при формировании Excel.');
  }
};
