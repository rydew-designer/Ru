/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Settings, Plus, Calendar, Clock, CheckCircle2, Circle, AlertCircle, MoreVertical, Search, Filter, FileDown, ChevronRight, ChevronLeft, Trash2, Edit2, X, FileText, SortDesc, ArrowUpDown, BarChart3, CalendarDays, Download, Share, Tag, Palette, Sun, Moon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  format, 
  isAfter, 
  parseISO, 
  startOfDay, 
  endOfDay, 
  startOfWeek, 
  endOfWeek, 
  startOfMonth, 
  endOfMonth,
  isSameDay,
  addMonths,
  subMonths,
  eachDayOfInterval,
  isSameMonth,
  isWithinInterval,
  addDays,
  startOfQuarter,
  endOfQuarter
} from 'date-fns';
import { ru } from 'date-fns/locale';
import { db, Task, TaskStatus, Category } from './db';
import { cn } from './utils';
import { requestNotificationPermission, checkTaskNotifications } from './notifications';
import { exportToPDF, exportToExcel } from './export';

type FilterType = 'all' | 'today' | 'week' | 'month' | 'custom';
type SortType = 'due' | 'created' | 'updated' | 'status';

export default function App() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isSortMenuOpen, setIsSortMenuOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [currentTheme, setCurrentTheme] = useState('default');
  const [currentMode, setCurrentMode] = useState<'light' | 'dark'>('dark');
  const [notificationSound, setNotificationSound] = useState<string | null>(null);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [taskToDelete, setTaskToDelete] = useState<number | null>(null);

  const isMobile = useMemo(() => {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  }, []);

  const isIOS = useMemo(() => {
    return /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
  }, []);

  const [filter, setFilter] = useState<FilterType>('all');
  const [statusFilter, setStatusFilter] = useState<TaskStatus | 'all'>('all');
  const [sortBy, setSortBy] = useState<SortType>('due');
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isYearPickerOpen, setIsYearPickerOpen] = useState(false);
  
  // Custom Date Range
  const [dateRange, setDateRange] = useState<{ start: Date; end: Date }>({
    start: startOfDay(new Date()),
    end: endOfDay(new Date())
  });

  const [currentCalendarMonth, setCurrentCalendarMonth] = useState(new Date());
  
  // Form State
  const [formData, setFormData] = useState({
    title: '',
    comment: '',
    categoryId: undefined as number | undefined,
    category: 'Общее',
    dueDate: format(new Date(), 'yyyy-MM-dd'),
    dueTime: '12:00',
    status: TaskStatus.NOT_STARTED,
    reminders: [] as number[]
  });

  const allTasks = useLiveQuery(() => db.tasks.toArray()) || [];
  const categories = useLiveQuery(() => db.categories.toArray()) || [];

  // Initialize selected category if needed
  useEffect(() => {
    if (categories.length > 0 && formData.categoryId === undefined) {
      const defaultCat = categories.find(c => c.name === 'Общее') || categories[0];
      setFormData(prev => ({ ...prev, categoryId: defaultCat.id }));
    }
  }, [categories, formData.categoryId]);

  // Load notification sound
  useEffect(() => {
    const loadTheme = async () => {
      const themeSetting = await (db as any).settings.get('currentTheme');
      const theme = themeSetting ? themeSetting.value : 'default';
      setCurrentTheme(theme);
      document.documentElement.setAttribute('data-theme', theme);
      
      const modeSetting = await (db as any).settings.get('currentMode');
      const mode = modeSetting ? modeSetting.value : 'dark';
      setCurrentMode(mode);
      document.documentElement.setAttribute('data-mode', mode);
    };
    loadTheme();

    const loadSound = async () => {
      const soundSetting = await (db as any).settings.get('notificationSound');
      if (soundSetting) {
        setNotificationSound(soundSetting.value);
      }
    };
    loadSound();
  }, []);

  const handleSoundChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = event.target?.result as string;
      await (db as any).settings.put({ id: 'notificationSound', value: base64 });
      setNotificationSound(base64);
    };
    reader.readAsDataURL(file);
  };

  const handleThemeChange = async (theme: string) => {
    setCurrentTheme(theme);
    document.documentElement.setAttribute('data-theme', theme);
    await (db as any).settings.put({ id: 'currentTheme', value: theme });
  };

  const handleModeChange = async (mode: 'light' | 'dark') => {
    setCurrentMode(mode);
    document.documentElement.setAttribute('data-mode', mode);
    await (db as any).settings.put({ id: 'currentMode', value: mode });
  };

  const handleAddCategory = async () => {
    const trimmedName = newCategoryName.trim();
    if (!trimmedName) return false;
    try {
      if (editingCategory) {
        await db.categories.update(editingCategory.id!, { name: trimmedName });
        setEditingCategory(null);
      } else {
        await db.categories.add({ name: trimmedName });
      }
      setNewCategoryName('');
      return true;
    } catch (e) {
      console.error(e);
      alert('Категория с таким названием уже существует');
      return false;
    }
  };

  const handleDeleteCategory = async (id: number) => {
    // Optional: check if tasks exist for this category
    const tasksCount = await db.tasks.where('categoryId').equals(id).count();
    if (tasksCount > 0) {
      if (!confirm(`К этой категории привязано ${tasksCount} задач. Все равно удалить?`)) return;
    }
    await db.categories.delete(id);
    // Tasks will have an invalid categoryId, we should probably null it or update to default
    await db.tasks.where('categoryId').equals(id).modify({ categoryId: undefined });
  };
  
  const handleAddReminder = () => {
    setFormData(prev => ({
      ...prev,
      reminders: [...prev.reminders, 0] // 0 will be treated as empty for typing
    }));
  };

  const handleRemoveReminder = (index: number) => {
    setFormData(prev => ({
      ...prev,
      reminders: prev.reminders.filter((_, i) => i !== index)
    }));
  };

  const handleUpdateReminder = (index: number, val: string, unit: 'm' | 'h' = 'm') => {
    const num = val === '' ? 0 : parseInt(val);
    const mins = isNaN(num) ? 0 : (unit === 'h' ? num * 60 : num);
    setFormData(prev => {
      const updated = [...prev.reminders];
      updated[index] = mins;
      return { ...prev, reminders: updated };
    });
  };

  // Background checks for overdue status and notifications
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      let updatedSomething = false;

      allTasks.forEach(async (task) => {
        if (task.status !== TaskStatus.COMPLETED && task.status !== TaskStatus.OVERDUE) {
          const dueDateTime = parseISO(`${task.dueDate}T${task.dueTime}`);
          if (isAfter(now, dueDateTime)) {
            await db.tasks.update(task.id!, { status: TaskStatus.OVERDUE, updatedAt: Date.now() });
            updatedSomething = true;
          }
        }
      });
      
      checkTaskNotifications(allTasks);

      if (updatedSomething) {
        // Dexie will automatically update the live query
      }
    }, 60000); // Check every minute

    return () => clearInterval(interval);
  }, [allTasks]);

  const filteredTasks = (() => {
    let result = allTasks;

    // Filter by Date
    const now = new Date();
    if (filter === 'today') {
      result = result.filter(t => isSameDay(parseISO(t.dueDate), now));
    } else if (filter === 'week') {
      const start = startOfWeek(now, { weekStartsOn: 1 });
      const end = endOfWeek(now, { weekStartsOn: 1 });
      result = result.filter(t => {
        const d = parseISO(t.dueDate);
        return d >= start && d <= end;
      });
    } else if (filter === 'month') {
      const start = startOfMonth(now);
      const end = endOfMonth(now);
      result = result.filter(t => {
        const d = parseISO(t.dueDate);
        return d >= start && d <= end;
      });
    } else if (filter === 'custom') {
      result = result.filter(t => {
        const d = parseISO(t.dueDate);
        return d >= startOfDay(dateRange.start) && d <= endOfDay(dateRange.end);
      });
    }

    // Filter by Search
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(t => 
        t.title.toLowerCase().includes(q) || t.comment.toLowerCase().includes(q)
      );
    }

    // Filter by Category
    if (selectedCategoryId !== 'all') {
      result = result.filter(t => t.categoryId === selectedCategoryId);
    }

    // STRICT FILTERING: 
    // If statusFilter is 'all' (default), we ONLY show Active/New tasks.
    // Overdue and Completed (Archive) tasks are only visible when their specific tabs are clicked.
    if (statusFilter === 'all') {
      result = result.filter(t => t.status === TaskStatus.NOT_STARTED || t.status === TaskStatus.IN_PROGRESS);
    } else {
      // Filter by specific status (Active, Overdue, or Completed/Archive)
      result = result.filter(t => t.status === statusFilter);
    }

    // Apply Sorting
    return [...result].sort((a, b) => {
      switch (sortBy) {
        case 'due': {
          const da = `${a.dueDate}T${a.dueTime}`;
          const db_ = `${b.dueDate}T${b.dueTime}`;
          return da.localeCompare(db_);
        }
        case 'created':
          return (b.createdAt || 0) - (a.createdAt || 0); // Newest first
        case 'updated':
          return (b.updatedAt || 0) - (a.updatedAt || 0); // Recently updated first
        case 'status': {
          const statusOrder: Record<TaskStatus, number> = {
            [TaskStatus.OVERDUE]: 0,
            [TaskStatus.IN_PROGRESS]: 1,
            [TaskStatus.NOT_STARTED]: 2,
            [TaskStatus.COMPLETED]: 3,
          };
          return statusOrder[a.status] - statusOrder[b.status];
        }
        default:
          return 0;
      }
    });
  })();

  const reportTasks = useMemo(() => {
    let result = allTasks;

    // Report always filters by selected Date period & Category, but includes ALL statuses
    const now = new Date();
    if (filter === 'today') {
      result = result.filter(t => isSameDay(parseISO(t.dueDate), now));
    } else if (filter === 'week') {
      const start = startOfWeek(now, { weekStartsOn: 1 });
      const end = endOfWeek(now, { weekStartsOn: 1 });
      result = result.filter(t => {
        const d = parseISO(t.dueDate);
        return d >= start && d <= end;
      });
    } else if (filter === 'month') {
      const start = startOfMonth(now);
      const end = endOfMonth(now);
      result = result.filter(t => {
        const d = parseISO(t.dueDate);
        return d >= start && d <= end;
      });
    } else if (filter === 'custom') {
      result = result.filter(t => {
        const d = parseISO(t.dueDate);
        return d >= startOfDay(dateRange.start) && d <= endOfDay(dateRange.end);
      });
    }

    if (selectedCategoryId !== 'all') {
      result = result.filter(t => t.categoryId === selectedCategoryId);
    }

    const enriched = result.map(t => ({
      ...t,
      categoryName: categories.find(c => c.id === t.categoryId)?.name || t.category || 'Общее'
    }));

    return enriched;
  }, [allTasks, categories, filter, dateRange, selectedCategoryId]);

  const stats = useMemo(() => {
    return {
      total: allTasks.length,
      active: allTasks.filter(t => t.status === TaskStatus.IN_PROGRESS || t.status === TaskStatus.NOT_STARTED).length,
      overdue: allTasks.filter(t => t.status === TaskStatus.OVERDUE).length,
      completed: allTasks.filter(t => t.status === TaskStatus.COMPLETED).length,
    };
  }, [allTasks]);

  const handleSaveTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title) return;

    if (editingTask) {
      await db.tasks.update(editingTask.id!, {
        ...formData,
        updatedAt: Date.now()
      });
    } else {
      await db.tasks.add({
        ...formData,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
    }

    setIsAddModalOpen(false);
    setEditingTask(null);
    setFormData({
      title: '',
      comment: '',
      categoryId: categories.find(c => c.name === 'Общее')?.id || categories[0]?.id,
      category: 'Общее',
      dueDate: format(new Date(), 'yyyy-MM-dd'),
      dueTime: '12:00',
      status: TaskStatus.NOT_STARTED,
      reminders: []
    });
  };

  const handleEdit = (task: Task) => {
    setEditingTask(task);
    setFormData({
      title: task.title,
      comment: task.comment,
      categoryId: task.categoryId,
      category: task.category || 'Общее',
      dueDate: task.dueDate,
      dueTime: task.dueTime,
      status: task.status,
      reminders: task.reminders || []
    });
    setIsAddModalOpen(true);
  };

  const handleToggleStatus = async (task: Task) => {
    const nextStatusMap: Record<TaskStatus, TaskStatus> = {
      [TaskStatus.NOT_STARTED]: TaskStatus.IN_PROGRESS,
      [TaskStatus.IN_PROGRESS]: TaskStatus.COMPLETED,
      [TaskStatus.COMPLETED]: TaskStatus.NOT_STARTED,
      [TaskStatus.OVERDUE]: TaskStatus.COMPLETED,
    };
    await db.tasks.update(task.id!, { 
      status: nextStatusMap[task.status], 
      updatedAt: Date.now() 
    });
  };

  const handleDelete = async (id: number) => {
    setTaskToDelete(id);
  };

  const confirmDelete = async () => {
    if (taskToDelete !== null) {
      await db.tasks.delete(taskToDelete);
      setTaskToDelete(null);
      if (editingTask && editingTask.id === taskToDelete) {
        setIsAddModalOpen(false);
      }
    }
  };

  const currentFilterLabel = {
    all: statusFilter === 'all' ? 'Все задачи' : {
      [TaskStatus.IN_PROGRESS]: 'В работе',
      [TaskStatus.OVERDUE]: 'Просрочено',
      [TaskStatus.NOT_STARTED]: 'Ожидают',
      [TaskStatus.COMPLETED]: 'Завершено'
    }[statusFilter as TaskStatus],
    today: 'На сегодня',
    week: 'На неделю',
    month: 'На месяц',
    custom: `Период: ${format(dateRange.start, 'dd.MM')} - ${format(dateRange.end, 'dd.MM')}`
  }[filter];

  const calendarDays = useMemo(() => {
    const start = startOfWeek(startOfMonth(currentCalendarMonth), { weekStartsOn: 1 });
    const end = endOfWeek(endOfMonth(currentCalendarMonth), { weekStartsOn: 1 });
    return eachDayOfInterval({ start, end });
  }, [currentCalendarMonth]);

  return (
    <div id="app-container" className="min-h-screen bg-app-bg text-app-text pb-24" data-theme={currentTheme} data-mode={currentMode}>
      {/* Header */}
      <header className="sticky top-0 z-30 bg-app-bg border-b border-app-border">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-app-card rounded-xl flex items-center justify-center border border-app-border overflow-hidden shadow-xl">
              <div className="w-7 h-7 border-2 border-app-text rounded-full flex items-center justify-center">
                <span className="text-app-text font-bold text-sm leading-none translate-x-[0.5px]">D</span>
              </div>
            </div>
            <h1 className="text-xl font-bold text-app-text tracking-tight">
              RuDev
            </h1>
          </div>
          <div className="flex gap-1 items-center">
            <button 
              onClick={() => setIsSettingsOpen(true)}
              className="p-2 rounded-full hover:bg-app-card transition-colors flex items-center justify-center bg-app-bg border border-app-border"
              title="Настройки"
            >
              <Settings size={18} className="text-primary-light" />
            </button>
            <button 
              onClick={() => setIsCategoryModalOpen(true)}
              className="p-2 rounded-full hover:bg-app-card transition-colors"
              title="Категории"
            >
              <Tag size={18} className="text-app-text-muted" />
            </button>
            <button 
              onClick={() => setIsReportModalOpen(true)}
              className="p-2 rounded-full hover:bg-app-card transition-colors"
              title="Отчеты"
            >
              <BarChart3 size={18} className="text-app-text-muted" />
            </button>
            <button 
              onClick={() => setIsCalendarOpen(true)}
              className="p-2 rounded-full hover:bg-app-card transition-colors"
              title="Календарь"
            >
              <CalendarDays size={18} className="text-app-text-muted" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-md mx-auto px-6 pt-6 space-y-6">
        {/* Quick Stats / Tabs */}
        <div className="grid grid-cols-3 gap-2">
          <button 
            id="status-active-tab"
            onClick={() => {
              setStatusFilter('all');
            }}
            className={cn(
              "p-3 rounded-2xl text-left border-2 transition-all active:scale-[0.95] cursor-pointer",
              statusFilter === 'all' 
                ? "bg-primary border-primary-light shadow-lg shadow-primary/30" 
                : "bg-app-card border-app-border hover:border-zinc-700"
            )}
          >
            <div className="flex items-center gap-1.5 mb-1.5">
              <BarChart3 size={14} className={statusFilter === 'all' ? "text-white" : "text-blue-400"} />
              <span className={cn("text-[8px] font-black uppercase tracking-widest", statusFilter === 'all' ? "text-white" : "text-app-text-muted")}>Активные</span>
            </div>
            <p className="text-xl font-black text-app-text leading-none">{stats.active}</p>
          </button>

          <button 
            id="status-overdue-tab"
            onClick={() => {
              setStatusFilter(TaskStatus.OVERDUE);
            }}
            className={cn(
              "p-3 rounded-2xl text-left border-2 transition-all active:scale-[0.95] cursor-pointer",
              statusFilter === TaskStatus.OVERDUE 
                ? "bg-red-600 border-red-400 shadow-lg shadow-red-500/30" 
                : "bg-app-card border-app-border hover:border-zinc-700"
            )}
          >
            <div className="flex items-center gap-1.5 mb-1.5">
              <AlertCircle size={14} className={statusFilter === TaskStatus.OVERDUE ? "text-white" : "text-red-400"} />
              <span className={cn("text-[8px] font-black uppercase tracking-widest", statusFilter === TaskStatus.OVERDUE ? "text-white" : "text-app-text-muted")}>Просрочено</span>
            </div>
            <p className="text-xl font-black text-app-text leading-none">{stats.overdue}</p>
          </button>

          <button 
            id="status-archive-tab"
            onClick={() => {
              setStatusFilter(TaskStatus.COMPLETED);
            }}
            className={cn(
              "p-3 rounded-2xl text-left border-2 transition-all active:scale-[0.95] cursor-pointer",
              statusFilter === TaskStatus.COMPLETED 
                ? "bg-green-600 border-green-400 shadow-lg shadow-green-500/30" 
                : "bg-app-card border-app-border hover:border-zinc-700"
            )}
          >
            <div className="flex items-center gap-1.5 mb-1.5">
              <CheckCircle2 size={14} className={statusFilter === TaskStatus.COMPLETED ? "text-white" : "text-green-400"} />
              <span className={cn("text-[8px] font-black uppercase tracking-widest", statusFilter === TaskStatus.COMPLETED ? "text-white" : "text-app-text-muted")}>Архив</span>
            </div>
            <p className="text-xl font-black text-app-text leading-none">{stats.completed}</p>
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="space-y-3">
          <div className="flex gap-2 pb-2 overflow-x-auto scrollbar-none items-center">
            <button
              onClick={() => {
                setSelectedCategoryId('all');
                setStatusFilter('all');
              }}
              className={cn(
                "px-4 py-2 rounded-xl text-[10px] font-bold whitespace-nowrap transition-all border uppercase tracking-wider",
                selectedCategoryId === 'all' 
                  ? "bg-primary border-primary-light text-white" 
                  : "bg-app-card border-app-border text-app-text-muted hover:border-zinc-700"
              )}
            >
              Все
            </button>
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCategoryId(cat.id!);
                  if (statusFilter !== 'all') setStatusFilter('all');
                }}
                className={cn(
                  "px-4 py-2 rounded-xl text-[10px] font-bold whitespace-nowrap transition-all border uppercase tracking-wider",
                  selectedCategoryId === cat.id 
                    ? "bg-primary border-primary-light text-white" 
                    : "bg-app-card border-app-border text-app-text-muted hover:border-zinc-700"
                )}
              >
                {cat.name}
              </button>
            ))}
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-app-text-muted" size={18} />
            <input 
              type="text"
              placeholder="Поиск по задачам..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-app-card border border-app-border rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary transition-all text-app-text"
            />
          </div>
          
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none items-center">
            <div className="relative shrink-0">
               <button 
                onClick={() => setIsSortMenuOpen(!isSortMenuOpen)}
                className={cn(
                  "p-2 rounded-full border transition-all",
                  isSortMenuOpen ? "bg-primary border-primary-light text-white" : "bg-app-card border-app-border text-app-text-muted"
                )}
              >
                <ArrowUpDown size={16} />
              </button>
              
              <AnimatePresence>
                {isSortMenuOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setIsSortMenuOpen(false)} />
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95, y: 10 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95, y: 10 }}
                      className="absolute left-0 mt-2 w-48 bg-app-card border border-app-border rounded-xl z-50 p-1 overflow-hidden shadow-2xl"
                    >
                      {[
                        { id: 'due', label: 'По дедлайну' },
                        { id: 'created', label: 'По дате создания' },
                        { id: 'updated', label: 'По обновлению' },
                        { id: 'status', label: 'По статусу' },
                      ].map((s) => (
                        <button
                          key={s.id}
                          onClick={() => {
                            setSortBy(s.id as SortType);
                            setIsSortMenuOpen(false);
                          }}
                          className={cn(
                            "w-full text-left px-4 py-2.5 rounded-lg text-xs font-medium transition-colors",
                            sortBy === s.id ? "bg-primary text-white" : "text-app-text-muted hover:bg-app-bg"
                          )}
                        >
                          {s.label}
                        </button>
                      ))}
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            <div className="flex gap-2 shrink-0">
            {(['all', 'today', 'week', 'month', 'custom'] as FilterType[]).map((f) => (
              filter === 'custom' || f !== 'custom' ? (
                <button
                  key={f}
                  onClick={() => {
                    if (f === 'custom') {
                      setIsCalendarOpen(true);
                    } else {
                      setFilter(f);
                      if (statusFilter !== 'all') setStatusFilter('all');
                    }
                  }}
                  className={cn(
                    "px-4 py-2 rounded-full text-xs font-medium whitespace-nowrap transition-all",
                    filter === f 
                      ? "bg-primary text-white" 
                      : "bg-app-card text-app-text-muted border border-app-border hover:border-zinc-700"
                  )}
                >
                  {{
                    all: 'Все',
                    today: 'Сегодня',
                    week: 'Неделя',
                    month: 'Месяц',
                    custom: `Период`
                  }[f]}
                </button>
              ) : null
            ))}
          </div>
        </div>
      </div>

      {/* Task Section */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-app-text-muted uppercase tracking-wider">
              {currentFilterLabel} ({filteredTasks.length})
            </h2>
            <button 
              onClick={() => setIsReportModalOpen(true)}
              className="text-xs text-primary-light font-medium flex items-center gap-1 hover:text-primary transition-all"
            >
              <FileDown size={14} /> Отчет
            </button>
          </div>

          <div className="space-y-3">
            <AnimatePresence mode='popLayout'>
              {filteredTasks.length === 0 ? (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="py-12 flex flex-col items-center justify-center text-app-text-muted space-y-3"
                >
                  <div className="p-4 bg-app-card rounded-full border border-app-border">
                    <CheckCircle2 size={32} />
                  </div>
                  <p className="text-sm">Список задач пуст</p>
                </motion.div>
              ) : (
                filteredTasks.map((task) => (
                  <motion.div
                    key={task.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className={cn(
                      "group relative bg-app-card border p-4 rounded-2xl flex gap-4 items-start transition-all",
                      task.status === TaskStatus.COMPLETED 
                        ? "border-app-border opacity-60" 
                        : task.status === TaskStatus.OVERDUE 
                          ? "border-red-500/30 bg-app-card" 
                          : "border-app-border hover:border-primary/30"
                    )}
                  >
                    <button 
                      onClick={() => handleToggleStatus(task)}
                      className={cn(
                        "mt-1 p-0.5 rounded-full border-2 transition-all shrink-0",
                        task.status === TaskStatus.COMPLETED 
                          ? "bg-green-500 border-green-500" 
                          : task.status === TaskStatus.OVERDUE
                            ? "border-red-500"
                            : "border-app-border group-hover:border-primary"
                      )}
                    >
                      {task.status === TaskStatus.COMPLETED ? (
                        <CheckCircle2 size={18} className="text-white" />
                      ) : (
                        <div className="w-[18px] h-[18px]" />
                      )}
                    </button>

                    <div className="flex-1 space-y-1">
                      <div className="flex justify-between items-start">
                        <h3 className={cn(
                          "font-semibold text-base",
                          task.status === TaskStatus.COMPLETED && "line-through text-app-text-muted"
                        )}>
                          {task.title}
                        </h3>
                        <div className="flex items-center gap-1">
                          <button onClick={() => handleEdit(task)} className="p-1 text-app-text-muted hover:text-primary-light">
                            <Edit2 size={14} />
                          </button>
                          <button onClick={() => handleDelete(task.id!)} className="p-2 text-app-text-muted hover:text-red-400 hover:bg-app-bg rounded-lg transition-colors">
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                      
                      {task.comment && (
                        <p className="text-sm text-app-text-muted line-clamp-2">{task.comment}</p>
                      ) }

                      <div className="flex flex-wrap gap-2 pt-1">
                        <span className="px-2 py-0.5 bg-app-bg text-app-text-muted rounded text-[9px] font-bold tracking-wider uppercase border border-app-border">
                          {categories.find(c => c.id === task.categoryId)?.name || task.category || 'Общее'}
                        </span>
                      </div>

                      <div className="pt-2 flex flex-wrap gap-x-4 gap-y-2 text-[10px] uppercase font-bold tracking-widest">
                        <div className="flex items-center gap-1.5 text-app-text-muted">
                          <Calendar size={12} />
                          {format(parseISO(task.dueDate), 'dd MMM')}
                        </div>
                        <div className={cn(
                          "flex items-center gap-1.5",
                          task.status === TaskStatus.OVERDUE ? "text-red-400" : "text-app-text-muted"
                        )}>
                          <Clock size={12} />
                          {task.dueTime}
                        </div>
                        <div className={cn(
                          "px-2 py-0.5 rounded flex items-center gap-1",
                          task.status === TaskStatus.NOT_STARTED && "bg-app-bg text-app-text-muted",
                          task.status === TaskStatus.IN_PROGRESS && "bg-blue-600 text-white",
                          task.status === TaskStatus.COMPLETED && "bg-green-600 text-white",
                          task.status === TaskStatus.OVERDUE && "bg-red-600 text-white",
                        )}>
                          {{
                            [TaskStatus.NOT_STARTED]: 'Ожидает',
                            [TaskStatus.IN_PROGRESS]: 'В работе',
                            [TaskStatus.COMPLETED]: 'Готово',
                            [TaskStatus.OVERDUE]: 'Просрочено',
                          }[task.status]}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        </section>
      </main>

      {/* Floating Action Button */}
      <button 
        id="fab-add-task"
        onClick={() => {
          setEditingTask(null);
          setFormData({
            title: '',
            comment: '',
            categoryId: categories.find(c => c.name === 'Общее')?.id || categories[0]?.id,
            category: 'Общее',
            dueDate: format(new Date(), 'yyyy-MM-dd'),
            dueTime: '12:00',
            status: TaskStatus.NOT_STARTED,
            reminders: []
          });
          setIsAddModalOpen(true);
        }}
        className="fixed bottom-8 right-8 w-14 h-14 bg-primary text-white rounded-full flex items-center justify-center transition-opacity z-40 hover:opacity-90 active:opacity-100"
      >
        <Plus size={28} />
      </button>

      <AnimatePresence>
        {isCalendarOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCalendarOpen(false)}
              className="absolute inset-0 bg-black/95"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm bg-app-card border border-app-border rounded-3xl p-6 overflow-hidden"
            >
              <div className="flex items-center justify-between mb-4">
                <button onClick={() => {
                  if (isYearPickerOpen) return;
                  setCurrentCalendarMonth(subMonths(currentCalendarMonth, 1));
                }} className="p-2 hover:bg-app-bg rounded-lg transition-colors border border-transparent hover:border-app-border">
                  <ChevronLeft size={20} />
                </button>
                <div className="flex items-center gap-1">
                   <button 
                    onClick={() => setIsYearPickerOpen(!isYearPickerOpen)}
                    className="font-bold text-lg capitalize hover:text-primary-light transition-colors text-app-text"
                  >
                    {format(currentCalendarMonth, 'LLLL', { locale: ru })}
                  </button>
                  <button 
                    onClick={() => setIsYearPickerOpen(!isYearPickerOpen)}
                    className="font-bold text-lg hover:text-primary-light transition-colors flex items-center gap-1 text-app-text"
                  >
                    {format(currentCalendarMonth, 'yyyy')}
                    <ArrowUpDown size={14} className="text-app-text-muted" />
                  </button>
                </div>
                <button onClick={() => {
                  if (isYearPickerOpen) return;
                  setCurrentCalendarMonth(addMonths(currentCalendarMonth, 1));
                }} className="p-2 hover:bg-app-bg rounded-lg transition-colors border border-transparent hover:border-app-border">
                  <ChevronRight size={20} />
                </button>
              </div>

              {isYearPickerOpen ? (
                <div className="max-h-[300px] overflow-y-auto grid grid-cols-3 gap-2 p-2 scrollbar-none">
                  {Array.from({ length: 41 }, (_, i) => new Date().getFullYear() - 20 + i).map(year => (
                    <button
                      key={year}
                      onClick={() => {
                        const newDate = new Date(currentCalendarMonth);
                        newDate.setFullYear(year);
                        setCurrentCalendarMonth(newDate);
                        setIsYearPickerOpen(false);
                      }}
                      className={cn(
                        "py-3 rounded-xl text-sm font-bold transition-all",
                        currentCalendarMonth.getFullYear() === year 
                          ? "bg-primary text-white" 
                          : "bg-app-bg text-app-text-muted border border-app-border hover:border-zinc-700"
                      )}
                    >
                      {year}
                    </button>
                  ))}
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-7 gap-1 mb-2">
                    {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map(day => (
                      <div key={day} className="text-center text-[10px] font-bold text-app-text-muted uppercase py-1">
                        {day}
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-7 gap-1">
                    {calendarDays.map((day, idx) => {
                      const isSelected = isSameDay(day, dateRange.start) || isSameDay(day, dateRange.end);
                      const isInRange = isWithinInterval(day, { start: dateRange.start, end: dateRange.end });
                      const isCurrentMonth = isSameMonth(day, currentCalendarMonth);

                      return (
                        <button
                          key={idx}
                          onClick={() => {
                            if (isAfter(day, dateRange.start) && isSameDay(dateRange.start, dateRange.end)) {
                              setDateRange({ ...dateRange, end: day });
                            } else {
                              setDateRange({ start: day, end: day });
                            }
                          }}
                          className={cn(
                            "h-10 w-full rounded-xl text-sm font-medium transition-all flex items-center justify-center relative",
                            !isCurrentMonth && "opacity-20",
                            isSelected ? "bg-primary text-white shadow-lg shadow-primary/30" : 
                            isInRange ? "bg-app-bg text-primary-light border border-primary/20" : "hover:bg-app-bg text-app-text-muted hover:text-app-text"
                          )}
                        >
                          {format(day, 'd')}
                          {allTasks.some(t => isSameDay(parseISO(t.dueDate), day)) && (
                            <div className="absolute bottom-1.5 w-1 h-1 bg-primary rounded-full" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </>
              )}

              <div className="mt-6 flex gap-3">
                <button 
                  onClick={() => {
                    setFilter('custom');
                    setIsCalendarOpen(false);
                    if (statusFilter !== 'all') setStatusFilter('all');
                  }}
                  className="flex-1 bg-primary hover:bg-primary-dark text-white py-4 rounded-xl font-bold text-sm transition-all"
                >
                  Применить
                </button>
                <button 
                  onClick={() => setIsCalendarOpen(false)}
                  className="px-4 bg-app-bg hover:bg-app-card border border-app-border py-4 rounded-xl font-bold text-sm transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddModalOpen(false)}
              className="absolute inset-0 bg-black"
            />
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="relative w-full max-w-md bg-app-card rounded-t-[32px] sm:rounded-3xl p-8 border-t border-app-border shadow-2xl"
            >
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-xl font-bold text-app-text">
                  {editingTask ? 'Редактировать задачу' : 'Новая задача'}
                </h2>
                <button onClick={() => setIsAddModalOpen(false)} className="p-2 bg-app-bg border border-app-border rounded-full hover:bg-app-card transition-colors">
                  <X size={20} className="text-app-text-muted" />
                </button>
              </div>

              <form onSubmit={handleSaveTask} className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-1.5">
                  <label className="text-xs font-bold text-app-text-muted uppercase ml-1">Что нужно сделать?</label>
                    <input 
                      autoFocus
                      required
                      type="text"
                      placeholder="Название задачи..."
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      className="w-full bg-app-bg border border-app-border rounded-2xl py-4 px-5 focus:ring-0 focus:border-primary transition-colors font-medium text-app-text"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-app-text-muted uppercase ml-1">Комментарий</label>
                    <textarea 
                      placeholder="Дополнительные детали..."
                      rows={3}
                      value={formData.comment}
                      onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                      className="w-full bg-app-bg border border-app-border rounded-2xl py-4 px-5 focus:ring-2 focus:ring-primary transition-all resize-none text-sm text-app-text"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-app-text-muted uppercase ml-1">Категория</label>
                    <div className="flex gap-2">
                       <select 
                        value={formData.categoryId}
                        onChange={(e) => setFormData({ ...formData, categoryId: parseInt(e.target.value) })}
                        className="flex-1 bg-app-bg border border-app-border rounded-2xl py-4 px-5 focus:ring-2 focus:ring-primary transition-all text-sm appearance-none text-app-text"
                      >
                        {categories.map(cat => (
                          <option key={cat.id} value={cat.id}>{cat.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-app-text-muted uppercase ml-1">Дата</label>
                      <input 
                        type="date"
                        value={formData.dueDate}
                        onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                        className={cn(
                          "w-full bg-app-bg border border-app-border rounded-2xl py-4 px-4 focus:ring-2 focus:ring-primary transition-all text-sm text-app-text",
                          currentMode === 'dark' ? "color-scheme-dark" : "color-scheme-light"
                        )}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-app-text-muted uppercase ml-1">Время</label>
                      <input 
                        type="time"
                        value={formData.dueTime}
                        onChange={(e) => setFormData({ ...formData, dueTime: e.target.value })}
                        className={cn(
                          "w-full bg-app-bg border border-app-border rounded-2xl py-4 px-4 focus:ring-2 focus:ring-primary transition-all text-sm text-app-text",
                          currentMode === 'dark' ? "color-scheme-dark" : "color-scheme-light"
                        )}
                      />
                    </div>
                  </div>

                  {editingTask && (
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-app-text-muted uppercase ml-1">Статус</label>
                      <select 
                        value={formData.status}
                        onChange={(e) => setFormData({ ...formData, status: e.target.value as TaskStatus })}
                        className="w-full bg-app-bg border border-app-border rounded-2xl py-4 px-5 focus:ring-2 focus:ring-primary transition-all text-sm appearance-none text-app-text"
                      >
                        <option value={TaskStatus.NOT_STARTED}>Не начато</option>
                        <option value={TaskStatus.IN_PROGRESS}>Выполняется</option>
                        <option value={TaskStatus.COMPLETED}>Выполнено</option>
                        <option value={TaskStatus.OVERDUE}>Просрочено</option>
                      </select>
                    </div>
                  )}

                  <div className="space-y-2">
                    <div className="flex items-center justify-between ml-1">
                      <label className="text-xs font-bold text-app-text-muted uppercase">Напоминания до срока</label>
                      <button 
                        type="button"
                        onClick={handleAddReminder}
                        className="text-[10px] font-bold text-primary-light uppercase tracking-wider hover:text-primary transition-all"
                      >
                        + Добавить
                      </button>
                    </div>
                    <div className="space-y-2">
                      {formData.reminders.map((mins, idx) => {
                        const isHours = mins > 0 && mins >= 60 && mins % 60 === 0;
                        const currentUnit = isHours ? 'h' : 'm';
                        const displayVal = mins === 0 ? '' : (isHours ? (mins / 60).toString() : mins.toString());

                        return (
                          <div key={idx} className="flex items-center bg-app-bg rounded-2xl p-1 gap-2 border border-app-border">
                            <input 
                              type="number"
                              placeholder="0"
                              value={displayVal}
                              onChange={(e) => handleUpdateReminder(idx, e.target.value, currentUnit)}
                              className="bg-transparent border-none py-2 pl-4 w-20 text-sm focus:ring-0 appearance-none text-app-text placeholder:text-app-text-muted"
                            />
                            <div className="flex gap-1 h-8">
                              <button 
                                type="button"
                                onClick={() => handleUpdateReminder(idx, displayVal, 'm')}
                                className={cn(
                                  "px-2 rounded-lg text-[10px] font-bold transition-colors",
                                  currentUnit === 'm' ? "bg-primary text-white" : "bg-app-card text-app-text-muted border border-app-border"
                                )}
                              >
                                МИН
                              </button>
                              <button 
                                type="button"
                                onClick={() => handleUpdateReminder(idx, displayVal, 'h')}
                                className={cn(
                                  "px-2 rounded-lg text-[10px] font-bold transition-colors",
                                  currentUnit === 'h' ? "bg-primary text-white" : "bg-app-card text-app-text-muted border border-app-border"
                                )}
                              >
                                ЧАС
                              </button>
                            </div>
                            <div className="flex-1" />
                            <button 
                              type="button"
                              onClick={() => handleRemoveReminder(idx)}
                              className="p-2 hover:bg-app-card rounded-xl transition-colors mr-1"
                            >
                              <X size={16} className="text-app-text-muted" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  {editingTask && (
                    <button 
                      type="button"
                      onClick={() => {
                        handleDelete(editingTask.id!);
                        setIsAddModalOpen(false);
                      }}
                      className="px-6 bg-app-bg hover:bg-app-card text-red-400 font-bold py-4 rounded-2xl transition-all border border-app-border"
                    >
                      <Trash2 size={20} />
                    </button>
                  )}
                  <button 
                    type="submit"
                    className="flex-1 bg-primary hover:bg-primary-dark text-white font-bold py-4 rounded-2xl active:scale-[0.98] transition-all"
                  >
                    {editingTask ? 'Сохранить' : 'Создать задачу'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Report Modal */}
      <AnimatePresence>
        {isReportModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsReportModalOpen(false)}
              className="absolute inset-0 bg-black"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm bg-zinc-900 border border-zinc-800 rounded-3xl p-8"
            >
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-zinc-800 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-zinc-700">
                  <FileText className="text-primary-light" size={32} />
                </div>
                <h2 className="text-xl font-bold mb-2">Экспорт отчета</h2>
                <p className="text-sm text-zinc-400">Выберите формат для выгрузки текущего списка ({filteredTasks.length} задач)</p>
              </div>

              <div className="grid grid-cols-1 gap-3">
                <button 
                  onClick={async () => {
                    await exportToPDF(reportTasks, currentFilterLabel);
                    setIsReportModalOpen(false);
                  }}
                  className="w-full flex items-center justify-between p-4 bg-zinc-800 hover:bg-zinc-700 rounded-2xl border border-zinc-700 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-zinc-900 rounded-lg">
                      <FileText className="text-red-400" size={20} />
                    </div>
                    <span className="font-semibold text-sm">PDF Документ</span>
                  </div>
                  <ChevronRight size={18} className="text-zinc-600" />
                </button>

                <button 
                  onClick={() => {
                    exportToExcel(reportTasks, currentFilterLabel);
                    setIsReportModalOpen(false);
                  }}
                  className="w-full flex items-center justify-between p-4 bg-zinc-800 hover:bg-zinc-700 rounded-2xl border border-zinc-700 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-zinc-900 rounded-lg">
                      <BarChart3 className="text-green-400" size={20} />
                    </div>
                    <span className="font-semibold text-sm">Excel Таблица</span>
                  </div>
                  <ChevronRight size={18} className="text-zinc-600" />
                </button>
              </div>

              <button 
                onClick={() => setIsReportModalOpen(false)}
                className="w-full mt-6 text-zinc-500 text-sm font-medium hover:text-zinc-300"
              >
                Отмена
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {taskToDelete !== null && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setTaskToDelete(null)}
              className="absolute inset-0 bg-black"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-xs bg-zinc-900 border border-zinc-800 rounded-3xl p-8 text-center"
            >
              <div className="w-16 h-16 bg-app-bg rounded-full flex items-center justify-center mx-auto mb-4 border border-app-border">
                <Trash2 className="text-red-400" size={32} />
              </div>
              <h3 className="text-lg font-bold mb-2">Удалить задачу?</h3>
              <p className="text-app-text-muted text-sm mb-8 leading-relaxed">
                Это действие нельзя будет отменить. Вы уверены?
              </p>
              
              <div className="flex flex-col gap-3">
                <button 
                  onClick={confirmDelete}
                  className="w-full bg-red-500 hover:bg-red-600 text-white py-4 rounded-2xl font-bold text-sm transition-all"
                >
                  Удалить
                </button>
                <button 
                  onClick={() => setTaskToDelete(null)}
                  className="w-full bg-app-bg hover:bg-app-card text-app-text rounded-2xl font-bold text-sm transition-all border border-app-border"
                >
                  Отмена
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* Settings Modal */}
      <AnimatePresence>
        {isSettingsOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSettingsOpen(false)}
              className="absolute inset-0 bg-black/95"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm bg-app-card border border-app-border rounded-3xl p-8"
            >
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-xl font-bold">Настройки</h2>
                <button onClick={() => setIsSettingsOpen(false)} className="p-2 bg-app-bg rounded-full border border-app-border">
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-6">
                <div className="space-y-3">
                  <label className="text-xs font-bold text-app-text-muted uppercase ml-1">Режим</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => handleModeChange('light')}
                      className={cn(
                        "flex items-center justify-center gap-2 py-3 rounded-xl border-2 transition-all",
                        currentMode === 'light' 
                          ? "bg-primary text-white border-primary-light shadow-lg" 
                          : "bg-app-bg border-app-border text-app-text-muted hover:border-zinc-500"
                      )}
                    >
                      <Sun size={18} />
                      <span className="font-bold text-sm">Светлая</span>
                    </button>
                    <button
                      onClick={() => handleModeChange('dark')}
                      className={cn(
                        "flex items-center justify-center gap-2 py-3 rounded-xl border-2 transition-all",
                        currentMode === 'dark' 
                          ? "bg-primary text-white border-primary-light shadow-lg" 
                          : "bg-app-bg border-app-border text-app-text-muted hover:border-zinc-500"
                      )}
                    >
                      <Moon size={18} />
                      <span className="font-bold text-sm">Темная</span>
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-xs font-bold text-app-text-muted uppercase ml-1">Акцентный цвет</label>
                  <div className="grid grid-cols-6 gap-2">
                    {[
                      { id: 'default', color: '#6366f1' },
                      { id: 'purple', color: '#a855f7' },
                      { id: 'green', color: '#22c55e' },
                      { id: 'orange', color: '#f97316' },
                      { id: 'blue', color: '#0ea5e9' },
                      { id: 'rose', color: '#f43f5e' }
                    ].map(t => (
                      <button
                        key={t.id}
                        onClick={() => handleThemeChange(t.id)}
                        className={cn(
                          "w-full aspect-square rounded-xl transition-all border-2 flex items-center justify-center",
                          currentTheme === t.id ? "border-white scale-110 shadow-lg" : "border-transparent opacity-60 hover:opacity-100"
                        )}
                        style={{ backgroundColor: t.color }}
                      >
                        {currentTheme === t.id && <CheckCircle2 size={16} className="text-white" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-xs font-bold text-app-text-muted uppercase ml-1">Звук уведомления</label>
                  <div className="space-y-4">
                    <button 
                      onClick={() => document.getElementById('sound-input')?.click()}
                      className="w-full flex items-center justify-between p-4 bg-app-bg hover:bg-app-card rounded-2xl border border-app-border transition-all text-left"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-app-card rounded-lg">
                          <Download className="text-primary-light" size={20} />
                        </div>
                        <div>
                          <p className="font-semibold text-sm">Выбрать MP3</p>
                          <p className="text-[10px] text-app-text-muted truncate max-w-[180px]">
                            {notificationSound ? 'Звук установлен' : 'По умолчанию'}
                          </p>
                        </div>
                      </div>
                    </button>
                    <input 
                      id="sound-input"
                      type="file"
                      accept="audio/mpeg"
                      onChange={handleSoundChange}
                      className="hidden"
                    />

                    {notificationSound && (
                      <button 
                        onClick={() => {
                          const audio = new Audio(notificationSound);
                          audio.play();
                        }}
                        className="w-full py-3 bg-app-bg border border-app-border rounded-xl text-xs font-bold hover:bg-app-card transition-colors shadow-sm"
                      >
                        Прослушать звук
                      </button>
                    )}

                    {notificationSound && (
                      <button 
                        onClick={async () => {
                          await (db as any).settings.delete('notificationSound');
                          setNotificationSound(null);
                        }}
                        className="w-full text-xs text-red-400 font-medium hover:text-red-300"
                      >
                        Сбросить на стандартный
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <button 
                onClick={() => setIsSettingsOpen(false)}
                className="w-full mt-8 bg-primary py-4 rounded-2xl font-bold text-sm hover:bg-primary-dark transition-all"
              >
                Готово
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Category Management Modal */}
      <AnimatePresence>
        {isCategoryModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setIsCategoryModalOpen(false);
                setEditingCategory(null);
                setNewCategoryName('');
              }}
              className="absolute inset-0 bg-black/95"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm bg-app-card border border-app-border rounded-3xl p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">Категория</h2>
                <button 
                  onClick={() => {
                    setIsCategoryModalOpen(false);
                    setEditingCategory(null);
                    setNewCategoryName('');
                  }} 
                  className="w-10 h-10 flex items-center justify-center bg-app-bg rounded-full hover:bg-app-card border border-app-border transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="space-y-6">
                {/* Input row */}
                <form 
                  onSubmit={async (e) => {
                    e.preventDefault();
                    if (newCategoryName.trim()) {
                      const success = await handleAddCategory();
                      if (success) {
                        setIsCategoryModalOpen(false);
                        setEditingCategory(null);
                        setNewCategoryName('');
                      }
                    }
                  }}
                  className="flex flex-col gap-2"
                >
                  <input 
                    autoFocus
                    type="text"
                    placeholder="Название категории..."
                    value={newCategoryName}
                    onChange={(e) => setNewCategoryName(e.target.value)}
                    className="w-full bg-app-bg border border-app-border rounded-xl px-5 focus:outline-none focus:border-primary text-app-text text-sm h-14 transition-all font-bold"
                  />
                </form>

                {/* Categories List */}
                <div className="max-h-[350px] overflow-y-auto space-y-2 scrollbar-none pb-2">
                  {categories.map(cat => (
                    <div 
                      key={cat.id} 
                      className="w-full h-14 flex items-center px-4 bg-app-bg text-app-text rounded-xl border border-app-border shadow-sm transition-all"
                    >
                      <span className="truncate flex-1 text-left font-bold text-sm">
                        {cat.name}
                      </span>
                      
                      <div className="flex items-center gap-2 shrink-0">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingCategory(cat);
                            setNewCategoryName(cat.name);
                          }}
                          className="w-9 h-9 flex items-center justify-center bg-app-card border border-app-border rounded-lg text-app-text hover:bg-app-bg transition-all"
                        >
                          <Edit2 size={16} />
                        </button>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteCategory(cat.id!);
                          }}
                          className="w-9 h-9 flex items-center justify-center bg-red-600/20 rounded-lg text-red-500 hover:bg-red-600/40 transition-all font-bold"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-8">
                <button 
                  onClick={async () => {
                    if (newCategoryName.trim()) {
                      const success = await handleAddCategory();
                      if (!success) return; // Don't close if name exists/error
                    }
                    setIsCategoryModalOpen(false);
                    setEditingCategory(null);
                    setNewCategoryName('');
                  }}
                  className="w-full bg-primary h-14 rounded-xl flex items-center justify-center font-bold text-sm hover:bg-primary-dark transition-all shadow-lg active:scale-[0.98]"
                >
                  Готово
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

